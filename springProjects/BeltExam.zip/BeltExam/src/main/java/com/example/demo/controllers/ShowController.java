package com.example.demo.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.models.Show;
import com.example.demo.services.ShowService;


@Controller
public class ShowController {

	@Autowired
	ShowService showService;
	
	
	@GetMapping("shows/{showId}")
    public String show(Model model,@PathVariable("showId")Long showId) {
        System.out.print(showId);
        Show show=showService.findShow(showId);
        model.addAttribute("show", show);
        return "Show.jsp";
    }
	

	@RequestMapping("/shows")
    public String index(Model model) {
        List<Show> shows = showService.allShows();
        model.addAttribute("shows", shows);
        return "home.jsp";
        }
	
	@RequestMapping("/shows/new")
    public String newShow(@ModelAttribute("show") Show show) {
        return "NewShow.jsp";
    }
    @RequestMapping(value="/shows", method=RequestMethod.POST)
    public String create(@Valid @ModelAttribute("show") Show show, BindingResult result) {
        if (result.hasErrors()) {
            return "NewShow.jsp";
        } else {
        	showService.createShow(show);
            return "redirect:/shows";
        }
    }
    
    @GetMapping("/shows/{id}/edit")
    public String edit(@PathVariable("id") Long id, Model model) {
    	Show show = showService.findShow(id);
        model.addAttribute("show", show);
        return "EditShow.jsp";
    }
    
    @PutMapping(value="/shows/{id}/update")
    public String update(@Valid @ModelAttribute("show") Show show, BindingResult result, @PathVariable("id") Long id, Model model) {
        if (result.hasErrors()) {
            return "EditShow.jsp";
        } else {
        	showService.updateShow(show,id);
            return "redirect:/shows";
        }
    }
    
    @RequestMapping(value="/{id}/delete",method={RequestMethod.GET, RequestMethod.POST})
    public String delete(@PathVariable("id") Long id) {
    	showService.deleteShow(id);
		return "redirect:/shows";
    	
    }
}
