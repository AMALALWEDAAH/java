package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.example.demo.models.Show;
import com.example.demo.repositories.ShowRepository;


@Service
public class ShowService {

	private final ShowRepository showRepository;
	public ShowService(ShowRepository showRepository) {
		this.showRepository = showRepository;
		}
	// returns all the Show
		public List<Show> allShows() {
			return showRepository.findAll();
			}
		// creates a Show
		public Show createShow(Show b) {
			return showRepository.save(b);
			}
		// retrieves a Show
		public Show findShow(Long id) {
			Optional<Show> optionalShow = showRepository.findById(id);
			if(optionalShow.isPresent()) {
				return optionalShow.get();
				} else {
					return null;
					}
			}
		
		public void deleteShow(Long id) {
			// TODO Auto-generated method stub
			showRepository.deleteById(id);
		}
		
		public Show updateShow(@Valid Show show,Long id) {
			// TODO Auto-generated method stub
			Show show1 = showRepository.findById(id).get();
			show1.setTitle(show.getTitle());
			show1.setDescription(show.getDescription());
			show1.setNetwork(show.getNetwork());
			
				return showRepository.save(show1);
		}
}
