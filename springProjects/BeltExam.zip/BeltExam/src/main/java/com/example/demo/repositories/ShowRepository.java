package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.models.Show;



@Repository
public interface ShowRepository extends CrudRepository<Show, Long> {

	 // this method retrieves all the Shows from the database
    List<Show> findAll();
    // this method finds Show with descriptions containing the search string
    List<Show> findByDescriptionContaining(String search);
    // this method counts how many titles contain a certain string
    Long countByTitleContaining(String search);
    // this method deletes a Shows that starts with a specific title
    Long deleteByTitleStartingWith(String search);
}
