package com.example.demo.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="shows")
public class Show {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    @NotNull
	    @Size(min = 5, message="must be provided.")
	    private String title;
	    @NotNull
	    @Size(min = 5, message="must be provided.")
	    private String description;
	    @NotNull
	    @Size(min = 3, message="must be provided.")
	    private String network;
	    // This will not allow the createdAt column to be updated after creation
	    @Column(updatable=false)
	    @DateTimeFormat(pattern="yyyy-MM-dd")
	    private Date createdAt;
	    @DateTimeFormat(pattern="yyyy-MM-dd")
	    private Date updatedAt;
	    
		public Show() {
		}
		public Show(Long id, @NotNull @Size(min = 5, message = "must be provided.") String title,
				@NotNull @Size(min = 5, message = "must be provided.") String description,
				@NotNull @Size(min = 3, message = "must be provided.") String network, Date createdAt, Date updatedAt) {
			super();
			this.id = id;
			this.title = title;
			this.description = description;
			this.network = network;
			this.createdAt = createdAt;
			this.updatedAt = updatedAt;
		}
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getNetwork() {
			return network;
		}
		public void setNetwork(String network) {
			this.network = network;
		}
		
		public Date getCreatedAt() {
			return createdAt;
		}
		
		public Date getUpdatedAt() {
			return updatedAt;
		}
		public void setUpdatedAt(Date updatedAt) {
			this.updatedAt = updatedAt;
		}
	
}
