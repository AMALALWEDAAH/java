package com.example.demo.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.models.House;
import com.example.demo.services.HouseService;
import com.example.demo.services.UserService;



@Controller
public class HouseController {

	@Autowired
	HouseService houseService;
	
	@Autowired
	UserService userService;
	
	@GetMapping("houses/{houseId}")
    public String show(Model model,@PathVariable("houseId")Long houseId,HttpSession session) {
		Long userId = (Long)session.getAttribute("user_id");
		if(userId != null) {
		User user=userService.findUserById(userId);
		model.addAttribute("user", user);
        House house=houseService.findHouse(houseId);
        model.addAttribute("house", house);
        return "Show.jsp";
		}else {
			return "redirect:/";
		}
    }
	
	@RequestMapping("/houses")
    public String index(Model model, HttpSession session) {
		Long id = (Long)session.getAttribute("user_id");
		if(id != null) {
			User user = userService.findUserById(id);
			List<House> userHouses = houseService.allHouses();
			model.addAttribute("user", user);
			model.addAttribute("userHouses", userHouses);
			return "home.jsp";
		}else {
			return "redirect:/";
		}
        }
	
	@GetMapping("/houses/new")
    public String newHouse(@ModelAttribute("house") House house) {
        return "New.jsp";
    }
    @PostMapping("/houses")
    public String create(@Valid @ModelAttribute("house") House house, BindingResult result,HttpSession session) {
        if (result.hasErrors()) {
            return "New.jsp";
        } else {
            Long id = (Long)session.getAttribute("user_id");
            User user = userService.findUserById(id);

            houseService.createHouse(house,(com.example.demo.models.User) user);
            return "redirect:/houses";
        }
    }
    
    @GetMapping("/houses/{id}/edit")
    public String edit(@ModelAttribute("updatedHouse") House house, @PathVariable("id") Long id, HttpSession session, Model model) {
		Long user_id = (Long) session.getAttribute("user_id") ;
		if(user_id != null) {
    	House house1 = houseService.findHouse(id);
        model.addAttribute("house", house1);
        return "Edit.jsp";
    }else {
    	return "redirect:/";
    }
    }
    @PutMapping("/houses/{id}/edit")
    public String update(@Valid @ModelAttribute("updateHouse") House house, BindingResult result, @PathVariable("id") Long id, HttpSession session) {
    	
        if (result.hasErrors()) {
            return "Edit.jsp";
        } else {
        	Long userId = (Long) session.getAttribute("user_id");
    		User user = userService.findUserById(userId);
    		houseService.updateHouse(house, (com.example.demo.models.User) user);
            return "redirect:/houses";
        }
		
    }
    
    @RequestMapping(value="/{id}/delete",method={RequestMethod.GET, RequestMethod.POST})
    public String delete(@PathVariable("id") Long id) {
    	houseService.deleteHouse(id);
		return "redirect:/houses";
    	
    }
}
