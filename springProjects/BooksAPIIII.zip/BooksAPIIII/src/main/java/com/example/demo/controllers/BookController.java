package com.example.demo.controllers;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.models.Book;
import com.example.demo.services.BookService;

@Controller
public class BookController {
	@Autowired
	BookService bookService;
	
	@GetMapping("/books/{bookId}")
    public String show(Model model,@PathVariable("bookId")Long bookId) {
        System.out.print(bookId);
        Book book=bookService.findBook(bookId);
        //ArrayList <Book> books =bookService.getAllBooks();
        //System.out.print(book);
        model.addAttribute("book", book);
        //model.addAttribute("books", books);
        return "show.jsp";
    }
}
