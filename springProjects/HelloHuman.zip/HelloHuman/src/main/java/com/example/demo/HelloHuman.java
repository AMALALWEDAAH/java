package com.example.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloHuman {
	@RequestMapping("/")
    public String  Hello(@RequestParam(value="fname",required=false) String fname ,@RequestParam(value="lname",required=false)String lname) {
	if(fname==null) {
		return " Hello Human";
      }else{
    	  return " Hello " + fname +" "+lname;
    }
	}
	
	
	
	//@RequestMapping("/")
   // public String  Hello(@RequestParam(value="fname",required=false) String fname ,@RequestParam(value="lname",required=false)String lname,@RequestParam(value="times",required=true)Integer times) {
	//	for(int i = 0;i<times;i++) {
	//		
	//		return " Hello " + fname +" "+lname;
	//	}
		
}

