package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.models.House;
import com.example.demo.models.User;
import com.example.demo.repositories.HouseRepository;



@Service
public class HouseService {

	private final HouseRepository houseRepository;
	public HouseService(HouseRepository houseRepository) {
		this.houseRepository = houseRepository;
		}
	// returns all the House
		public List<House> allHouses() {
			return houseRepository.findAll();
			}
		// creates a House
		public House createHouse(House h ,User user) {
			h.setUser(user);
			return houseRepository.save(h);
			}
		
		// retrieves a House
		public House findHouse(Long id) {
			Optional<House> optionalHouse = houseRepository.findById(id);
			if(optionalHouse.isPresent()) {
				return optionalHouse.get();
				} else {
					return null;
					}
			}
		
		public List<House> findAllHousesByUser(User user){
			return houseRepository.findByUser(user);
		}
		
		public void deleteHouse(Long id) {
			// TODO Auto-generated method stub
			houseRepository.deleteById(id);
		}
		
		public House updateHouse(House house,User user) {
			// TODO Auto-generated method stub
			house.setUser(user);
				return houseRepository.save(house);
		}
}
